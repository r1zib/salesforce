<?php

class Application_Model_DbTable_Product2 extends Zend_Db_Table_Abstract
{

    protected $_name = 'Product2';
    protected $_primary = 'Id';
    

    

}

