<?php

class Application_Model_DbTable_Opportunity extends Zend_Db_Table_Abstract
{

    protected $_name = 'Opportunity';
    protected $_primary = 'Id';
    

    

}

