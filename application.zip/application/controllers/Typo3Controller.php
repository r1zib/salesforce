<?php

class Typo3Controller extends Zend_Controller_Action
{

    public function init()
    {
    	$auth = Zend_Auth::getInstance();
    	if ($auth->hasIdentity()) {

    	} else {
    		$this->__connect();
    	}
    	
    }

    public function indexAction()
    {
        // action body
    }

    public function categoriesAction()
    {

    	$data = array('categories',explode(',', "Alubat,Archambault,Beneteau,Catamaran,Class 40,Delher,Dufour,Elan,Grand soleil,Heol,Jeanneau,J Boats,JPK,Mini,Nautitech,Pogo,RM,Swan,Wauquiez,X Yatchs"));
    	$this->_helper->json($data);
    	    	
    }

    public function opportunitiesAction()
    {
          	// action body
    	$category = $this->_getParam('category', '');
    	$opportunities = new Application_Model_Opportunities();
    	$sel = '';
    	if ($category != '') {
    		$sel = "Familly__c='".$category."'";
    	}	 
    	
    	$this->_helper->json($opportunities->fetchAll('Name,Id',$sel));
    }

    public function opportunityAction()
    {
    	// action body
    	$id = $this->_getParam('id', 0);
    	$opportunities = new Application_Model_Opportunities();
    	if ($id > 0) {
    		$this->_helper->json($opportunities->createJson($id));
    	}
    	
    }
    public function productsAction()
    {
    	// action body
    	$family = $this->_getParam('family', '');
    	$opportunities = new Application_Model_Products();
    	$sel = '';
    	if ($family != '') {
    		$sel = "Family='".$family."'";
    	}
    	 
    	$this->_helper->json($opportunities->fetchAll('Name,Id',$sel));
    	    	
    }
    
    public function productAction()
    {
    	// action body
    	$id = $this->_getParam('id', 0);
    	$name = $this->_getParam('name', '');
    	 
    	$product = new Application_Model_Products();
    	if ($id > 0) {
    		$this->_helper->json($product->find($id));
    	}
    	if ($name != '') {
    		$name = trim($name); 
    		$where = 'Name="'.$name.'"';
    		$info = $product->fetchAll('Id',$where);
    		if(isset($info[0]['Id'])) {
    			$this->_helper->json($product->find($info[0]['Id']));
    		}
    		//Zend_Debug::dump($where);
    		
       	}
    	
    	

    }

    public function __connect()
    {

    	/* Utilisation de l'adaptateur de Db */
    	$dbAdapter = Zend_Db_Table::getDefaultAdapter();
    	$authAdapter = new Zend_Auth_Adapter_DbTable($dbAdapter);
    	$authAdapter->setTableName('users')
    	->setIdentityColumn('username')
    	->setCredentialColumn('password')
    	->setCredentialTreatment('SHA1(CONCAT(?,salt))');

    	$authAdapter->setIdentity('admin');
    	$authAdapter->setCredential('password');
    	
    	/* On teste si le login est bon */
    	$auth = Zend_Auth::getInstance();
    	$result = $auth->authenticate($authAdapter);
    	if ($result->isValid()) {
    		/* il faut mettre les données comme pour un login 'normal' */
    		$user = $authAdapter->getResultRowObject();
    		$auth->getStorage()->write($user);
    		Azeliz_Registreconfig::getInstance()->init_config();
    	}
    		 
    	
    }



}











